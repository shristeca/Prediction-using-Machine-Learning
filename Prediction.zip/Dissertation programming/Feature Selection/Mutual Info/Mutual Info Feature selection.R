data <- read.csv(file.choose())
head(data)
summary(data)
ncol(data)
nrow(data)
library(FSelector)

n= nrow(data)

#Splitting the data into training data and testing set
indexes = sample(n,n*(75/100))
trainset = data[indexes,]   #75% training dat
testset = data[-indexes,]
dim(testset)
dim(trainset)
table(trainset$Class)

#Mutual information feature selection done on trainset
weights <- information.gain(Class~., trainset)
subset_info <- cutoff.k(weights, k = 10) #Selectin only 10 features
f <- as.simple.formula(subset_info, "Class")

#To collect the file that contains only the selected features
subset_info_gain <- data[, (names(data) %in% subset_info)]
ncol(subset_info_gain)
subset_info_gain <- as.data.frame(subset_info_gain)
dim(subset_info_gain)
summary(subset_info_gain)
value <- data$Class
subset_info_gain$Class <- value
dim(subset_info_gain)
write.csv(subset_info_gain,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\Feature Selection\\Mutual Info\\10 cls\\mutualinfo_10cls.csv', row.names = FALSE)

#To collect the trainset that contains only the selected features
feature_train <- trainset[, (names(trainset) %in% subset_info)]
ncol(feature_train)
feature_train <- as.data.frame(feature_train)
dim(feature_train)
summary(feature_train)
value <- trainset$Class
feature_train$Class <- value
dim(feature_train)
write.csv(feature_train,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\Feature Selection\\Mutual Info\\10 cls\\trainset_10cls.csv', row.names = FALSE)

#To collect the testset that contains only the selected features
feature_test <- testset[, (names(testset) %in% subset_info)]
ncol(feature_test)
feature_test <- as.data.frame(feature_test)
dim(feature_test)
summary(feature_test)
value <- testset$Class
feature_test$Class <- value
dim(feature_test)
write.csv(feature_test,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\Feature Selection\\Mutual Info\\10 cls\\testset_10cls.csv', row.names = FALSE)

#---------------------

