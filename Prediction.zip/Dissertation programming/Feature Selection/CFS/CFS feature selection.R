data <- read.csv(file.choose())
head(data)
summary(data)
ncol(data)
nrow(data)
library(FSelector)

n= nrow(data)

#Splitting the data into training data and testing set
indexes = sample(n,n*(75/100))
trainset = data[indexes,]  #75% training data
testset = data[-indexes,]
dim(testset)
dim(trainset)


#CFS feature selection done on train set
weights_cfs <- cfs(Class~., data)
f_cfs <- as.simple.formula(weights_cfs, "Class")

#To collect the file that contains only the selected features
feat_cfs <- data[, (names(data) %in% weights_cfs)]
ncol(feat_cfs)
feat_cfs <- as.data.frame(feat_cfs)
dim(feat_cfs)
summary(feat_cfs)
value <- data$Class
feat_cfs$Class <- value
dim(feat_cfs)
write.csv(feat_cfs,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\CFS\\10 cls\\cfs_10cls.csv', row.names = FALSE)

#To collect the trainset that contains only the selected features
feature_train <- trainset[, (names(trainset) %in% weights_cfs)]
ncol(feature_train)
feature_train <- as.data.frame(feature_train)
dim(feature_train)
summary(feature_train)
value <- trainset$Class
feature_train$Class <- value
dim(feature_train)
write.csv(feature_train,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\CFS\\10 cls\\trainset_10cls.csv', row.names = FALSE)

#To collect the testset that contains only the selected features
feature_test <- testset[, (names(testset) %in% weights_cfs)]
ncol(feature_test)
feature_test <- as.data.frame(feature_test)
dim(feature_test)
summary(feature_test)
value <- testset$Class
feature_test$Class <- value
dim(feature_test)
write.csv(feature_test,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\CFS\\10 cls\\testset_10cls.csv', row.names = FALSE)

#---------------------
