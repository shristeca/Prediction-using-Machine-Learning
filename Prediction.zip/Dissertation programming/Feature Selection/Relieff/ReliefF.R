data <- read.csv(file.choose())
head(data)
summary(data)
ncol(data)
nrow(data)
install.packages('CORElearn')
library(CORElearn)

n= nrow(data)

#Splitting the data into training and testing set
indexes = sample(n,n*(75/100))
trainset = data[indexes,]
testset = data[-indexes,]
dim(testset)
dim(trainset)

#ReliefF feature selectoion done on train set
values <- attrEval(Class~., trainset, costMatrix = NULL, 
                   outputNumericSplits=FALSE, estimator= "ReliefFexpRank", ReliefIterations=20)

#Sorting and getting the top 10 features 
names(values)
sorted<-sort(values, decreasing = TRUE)
sort_10<-head(sorted,10) 
sort_10<-names(sort_10)

#To collect the dataset that contains only the selected features
feat_relieff <- data[, (names(data) %in% sort_10)]
ncol(feat_relieff)
feat_relieff <- as.data.frame(feat_relieff)
dim(feat_relieff)
summary(feat_relieff)
value <- data$Class
feat_relieff$Class <- value
dim(feat_relieff)
write.csv(feat_relieff,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\Feature Selection\\Relieff\\ExpRank\\10 cls\\relif_10cls.csv', row.names = FALSE)

#To collect the trainset that contains only the selected features
feature_train <- trainset[, (names(trainset) %in% sort_10)]
ncol(feature_train)
feature_train <- as.data.frame(feature_train)
dim(feature_train)
summary(feature_train)
value <- trainset$Class
feature_train$Class <- value
dim(feature_train)
write.csv(feature_train,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\Feature Selection\\Relieff\\ExpRank\\10 cls\\trainset_10cls.csv', row.names = FALSE)

#To collect the testset that contains only the selected features
feature_test <- testset[, (names(testset) %in% sort_10)]
ncol(feature_test)
feature_test <- as.data.frame(feature_test)
dim(feature_test)
summary(feature_test)
value <- testset$Class
feature_test$Class <- value
dim(feature_test)
write.csv(feature_test,'C:\\Users\\feljo\\OneDrive\\Documents\\Thesis\\Programmes\\Feature Selection\\Relieff\\ExpRank\\10 cls\\testset_10cls.csv', row.names = FALSE)

#---------------------

